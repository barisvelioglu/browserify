module.exports = {
	initialize : function(){
		console.log("HomeService initialized!");
	}
}