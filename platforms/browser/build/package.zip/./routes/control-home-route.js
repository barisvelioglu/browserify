var $ = require("jquery")
var r = require('router');

r.addRoute('controlhome', function() {
    $('#app').html("controlhome");
});
